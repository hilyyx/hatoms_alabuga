from flask import Flask, render_template, request, redirect, url_for
import os
from ultralytics import YOLO
import matplotlib.pyplot as plt
import cv2
import numpy as np


print(result)
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

@app.route('/')
def index():
    return render_template('index.html', data = 1)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    if file:
        filename = file.filename
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        # Здесь вы можете использовать загруженный файл в вашем основном коде
        # Например, вы можете вызвать функцию, которая использует этот файл
        process_file(filepath)
        return redirect(url_for('index'))
        
def process_file(filepath):
    model = YOLO('last.pt')
    image = cv2.imread(f'{filepath}')
    result = model(image, imgsz = 640, iou = 0.4, conf = 0.1)
    print(result)

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)
